# Technical Portfolio

This repository hosts a technical portfolio built using [TechFolio](http://techfolios.github.io). 

See the quick start guide for instructions on how to tailor the template to your own needs.


